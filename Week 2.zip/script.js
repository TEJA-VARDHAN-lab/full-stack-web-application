// Load cart from LocalStorage on startup, or start empty
let cart = JSON.parse(localStorage.getItem('bookCart')) || [];

// Update the display immediately if we are on the dashboard
window.onload = () => {
    let countDisplay = document.getElementById("cartCount");
    if (countDisplay) countDisplay.innerText = cart.length;
};

// ===== CART WITH PERSISTENCE =====
function addToCart(book) {
    cart.push(book);
    localStorage.setItem('bookCart', JSON.stringify(cart)); // Save to browser
    
    let countDisplay = document.getElementById("cartCount");
    if (countDisplay) countDisplay.innerText = cart.length;
    
    alert(book + " added to cart");
}

function showCart() {
    if (cart.length === 0) {
        alert("Cart is empty");
    } else {
        alert("Cart Items:\n" + cart.join("\n"));
    }
}

// ===== MASTER FILTER (Combines Search + Category) =====
function filterBooks() {
    const searchQuery = document.getElementById("searchInput")?.value.toLowerCase() || "";
    const filterValue = document.getElementById("categoryFilter")?.value || "all";
    const cards = document.querySelectorAll(".book-card");

    cards.forEach(card => {
        const title = card.querySelector("h3").innerText.toLowerCase();
        const category = card.getAttribute("data-category");

        const matchesSearch = title.includes(searchQuery);
        const matchesFilter = filterValue === "all" || category === filterValue;

        if (matchesSearch && matchesFilter) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}

// Point your search input to use the master filter
function searchBooks() {
    filterBooks();
}

// ===== NAVIGATION =====
function goToDashboard() { window.location.href = "dashboard.html"; }
function goHome() { window.location.href = "index.html"; }

// ===== MODAL & UI =====
function viewDetail(book) {
    document.getElementById("modalTitle").innerText = book;
    document.getElementById("bookModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("bookModal").style.display = "none";
}

function toggleMenu() {
    document.getElementById("navMenu")?.classList.toggle("show");
}

function scrollToBooks() {
    document.getElementById("booksSection")?.scrollIntoView({ behavior: "smooth" });
}